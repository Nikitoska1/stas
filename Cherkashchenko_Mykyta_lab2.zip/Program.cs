﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CS_lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            double dlina = 0.0;
            double entropy = 0; 
            double quantity_information = 0.0;
            string waytofile = @"C:\Users\Iryna\Desktop\3 курс\CS\CS_lab1\texts\1.txt";
            string text = "";
                        

            //Console.OutputEncoding = Encoding.UTF8;

            using (StreamReader a = new StreamReader(path, Encoding.UTF8))
            {
                text = a.ReadToEnd();
                a.Close();
            }
            //виведення тексту
            //text = File.ReadAllText(path, Encoding.UTF8);
            //Console.WriteLine(text);

            dlina = text.Length;

            Dictionary<char, int> pair = new Dictionary<char, int>();

            foreach( char letter in text)
            {
                if (pair.ContainsKey(letter))
                {
                    pair[letter] += 1;
                }
                else
                { 
                    pair.Add(letter, 1);
                }
            }
            foreach (KeyValuePair<char, int> element in pair)
            {
                entropy -= (element.Value / dlina) * Math.Log(element.Value / dlina, 2);
                Console.WriteLine("Symbol: " + element.Key + " Frequency: " + element.Value + " Probability: " + element.Value / dlina);
            }

            quantity_information = entropy * dlina / 8;
            Console.WriteLine("Entropy bit: " + entropy + "\n" + "Info quantity byte: " + quantity_information);
            FileInfo file = new FileInfo(waytofile);
            Console.WriteLine("File name: " + file.Name + " File size byte: " + file.Length);
            Console.ReadKey();
        }
    }
}
